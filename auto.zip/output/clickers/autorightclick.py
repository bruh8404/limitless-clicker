import time
import pynput
import threading
from pynput.mouse import Controller, Button
from pynput.keyboard import Listener, KeyCode

click = False
mouse = Controller()

def autoclickerright():

    tkey= input("toggle key: ")

    toggle = KeyCode(char=tkey)



    speed = float(input("interval between clicks(seconds)(dont put as 0 only as it may lead to many problems): "))


    def clicker():
        while True:
            if click:
                mouse.click(Button.right, 1)
            time.sleep(speed)
        
    print("press " + tkey + " to toggle")


    def toggler(key):
        if key == toggle:
            global click
            click = not click

    click_thread = threading.Thread(target=clicker)
    click_thread.start()

    with Listener(on_press=toggler) as listener:
        listener.join()



